# class student:
#     name='Malek'
#     age=33
# x=student()
# print(type(x))
# print(x.name)
# =============================
# student={'name_1':'Malek','grades_1':[11,12,13,14,15],'name_2':'Ali','grades_2':[12,13,14,15,16]'name_3':'Amin','grades_3':[13,14,15,16,17]}
# for i in range(len(student)):
#     print(student[''])
#     for j in range(len(student[grade_1])):
# # =================================================
# x=[['Malek',10,20],['Ali',30,40],["Amin",50,60],['Maryam',70,80]]
# for i in x:
#     print(i)
# ====================
# x = [[1, 2, 3],
#      [4, 5, 6],
#      [7, 8, 9]]
# a=x[0][0],b=x[0][1],c=x[0][2],d=x[1][0],e=x[1][1],f=x[1][2],g=x[2][0],h=x[2][1],i=x[2][2]
# # det = x[0][0]*x[1][1]-x[0][1]*x[1][0]
# det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
# print(det)
# ==============================================
# def f(n):
#     if n==1:
#         return 1
#     else:
#         return n*f(n-1)
# n=int(input("Enter number: "))
# print("Factorial= ", f(n))
# =========================================
def fib(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return fib(n-1)+fib(n-2)
n=int(input("Enter number: "))
print("Fibonaci= ", fib(n))