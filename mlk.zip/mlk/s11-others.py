x=[[1,4],[-3,-2],[3,5]]
x.sort()
print(x)
def distance(p):
    return(p[0])**2+(p[1])**2
