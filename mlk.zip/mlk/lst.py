# x= [1,2,3,4,5,6,7]
# temp=0
# for i in x:
#     temp+=i
# print(temp)
# print(temp/len(x))
# print(sum(x)/len(x))
#==========================================
# x= [7,9,13,4,3]
# temp=0
# m=sum(x)/len(x)
# for y in x:
#     temp+=(y-m)**2
# var=temp/len(x)
# print(var)
# =========================================
# x=[1,2,3,4]
# y=[10,20,30,40]
# for i in [0,1,2,3]:
#     print(x[i]+y[i])
# for a,b in zip(x,y):
#     print(a+b)
#==========================================
# for i,x in enumerate(['a','b','c']):
    # print(i,x)
#==========================================
# x=[]
# for i in [1,2,3]:
#     x.append(input())
# print(x)
# x.pop(0)
# print(x)
# x.insert(0,10)
# print(x)
# x.remove(10)
# x.pop
# print(x)
#==========================================
# y=('a','b','c')
# print(type(y))
# print(y)
# n=input()
# for i in range(0, len(n)+1):
#     print(n[i]+": ", end='')
#     for j in range(0, int(n[i])):
#         print(n[i], end='')
#     print()
# y=input().split()
# z=[]
# for j in y:
#     z.append(int(j))
# print(z)
# z=[int(a) for a in input().split()]
# print(z)
# f=open('data.txt', 'r')
# for line in f.readlines():
#     print(line, end='')