# def crcl_1(n):
#     return 2*3.14*n
# def crcl_2(n):
#     return 3.14*(n**2)
# r=float(input())
# print("mohit= ", crcl_1(r))
# print("masahat= ", crcl_2(r))
# ================================
# def crcl(r, s):
#     if (s==True):
#         tmp=2*3.14*r
#     else:
#         tmp=3.14*(r**2)
#     return tmp
# r=float(input())
# str_tmp=input()
# if(str_tmp=="true"):
#     s=True
#     print("mohit: ", crcl(r,s))
# else:
#     s=False
#     print("masahat: ", crcl(r,s))
# lst=[1,2,3,4,5]
# x,y,z,n,m=lst
# print(x,y,z)
# x,*y,z=lst
# print(x,y,z)
# def avg(*x):
#     return sum(x)/len(x)
# y=[int(i) for i in input().split(" ")]
# print(avg(*y))
# details={'Name':'Malek','Age':33,'Address':'Tehran'}
# x=details.keys()
# y=details.values()
# z=list(details.items())
# print(len(details))
# print(x)
# print(y)
# print(z[1])
# for k in details.items():
#     print(k)
# for k,v in details.items():
#     print(k,v)
a={1,2,3,3,3,2}
print(type(a))
b=list(a)
print(b[1])
print(len(a))
print(1 in a)
print(1 not in a)