n=int(input())
# for i in range(0, n):
#     for j in range(0, i+1):
#         print("*", end="")
#     print()
#==================================
# for i in range(0,n):
#     for j in range(0,n):
#         if(i>=j):
#             print("*", end="")
#         else:
#             print("", end="")
#     print()
#==================================
# for i in range(0,n):
#     for j in range(0,n):
#         if(j<n-i-1):
#             print(" ", end="")
#         else:
#             print("*", end="")
#     print()
#==================================
# for i in range(0,n):
#     for j in range(0,2*n):
#         if(j<n-i):
#             print(" ", end="")
#         elif(j>n+i):
#             print(" ", end="")
#         else:
#             print("*", end="")
#     print()
#==================================
for i in range(n):
    if i < n//2+1:
        space = (n - (i*2+1))//2
        star = (i*2+1)
        print((space*" " + star*"*" + space*" ")*2)
    else:
        space = (i-n//2)
        star = (n-2*(i-n//2))
        print((space*" " + star*"*" + space*" ")*2)