name_lst=['Malek','Ali','Mohammad']
print(name_lst)
name_lst[0], name_lst[1]=name_lst[1],name_lst[0]
print(name_lst)
name_lst.insert(0,name_lst[1])
name_lst.pop(2)
print(name_lst)