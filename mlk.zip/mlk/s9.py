# def power(a,b):
#     tmp=1
#     for i in range(0,b):
#         tmp*=a
#     return tmp
# a=int(input())
# b=int(input())
# print(power(a,b))
# ================================
# def zero_counter(lst):
#     cu=0
#     for i in range(len(lst)):
#         if lst[i]!=0:
#             cu+=1
#     return cu
# lst=[int(j) for(j) in input().split(" ")]
# print(zero_counter(lst))
# ==================================
# import math
# def is_prime(n):
#     if n==1:
#         return False
#     elif n==2:
#         return True
#     elif n%2==0:
#         return False
#     else:
#         for i in range(3, round(math.sqrt(n))+1):
#             if n%i==0:
#                 return False
#         return True
# def mean_digit(n):
#     return sum([int(x) for x in n])/len(n)
# n=input("Please enter number: ")
# if is_prime(int(n))==True:
#     m=mean_digit(n)
#     if m%2==0:
#         print(m)
# else:
#     print("input number is not prime!")
# =======================================================
# f=open('data.txt','a')
# f.write("\nMalek")
# f.close
# ===============================
# import json
# with open("sample1.json",'r') as f:
#     data=json.load(f)
#     print(data)
#     print(type(data))
