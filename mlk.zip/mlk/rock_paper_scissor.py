# import random
# user_score = 0
# computer_score = 0

# while True:
#     command = input("please enter your choice (exit rock paper or scissors: )")
#     if command == "exit":
#         break
#     elif command == 'rock':
#         user_choice = "rock"
#     elif command == "paper":
#         user_choice = "paper"
#     elif command == "scissors":
#         user_choice = "scissors"
#     else:
#         print("invalid command!")
#         continue

#     computer_choice = random.choice(["rock", "paper", "scissors"])
#     if user_choice == computer_choice:
#         computer_score += 1
#         user_score += 1
#         print(
#             f"""your choice: {user_choice} score: {user_score}\ncomputer choice: {computer_choice} score: {computer_score}""")
#         print("draw")
#     elif (user_choice == "rock" and computer_choice == "scissors")\
#             or (user_choice == "paper" and computer_choice == "rock")\
#             or (user_choice == "scissors" and computer_choice == "paper"):
#         user_score += 3
#         print(
#             f"your choice: {user_choice} score: {user_score}\ncomputer choice: {computer_choice} score: {computer_score}")
#         print("you won!")
#     elif (computer_choice == "rock" and user_choice == "scissors")\
#             or (computer_choice == "paper" and user_choice == "rock")\
#             or (computer_choice == "scissors" and user_choice == "paper"):
#         computer_score += 3
#         print(
#             f"your choice: {user_choice} score: {user_score}\ncomputer choice: {computer_choice} score: {computer_score}")
#         print("you lose!")