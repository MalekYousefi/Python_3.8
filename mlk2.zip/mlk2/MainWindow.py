import csv
from PySide6.QtWidgets import QMainWindow
from ui12.mainwindowpy import Ui_MainWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.valid_username = "mohammad"
        self.valid_password = "123"
        self.data_dir = "data.csv"

        self.ui.check.clicked.connect(self.check)
        self.ui.exit.clicked.connect(self.exit)

    def check(self):
        username = self.ui.username.text()
        password = self.ui.password.text()
        id = self.read_data(username, password)
        if(id != -1):
            self.ui.result.setText("welcome!")
        else:
            self.ui.result.setText("Access Denied!")

        # self.ui.lineEdit.text()

    def exit(self):
        self.close()

    def read_data(self, username, password):
        with open(self.data_dir, 'r') as data_file:
            data = csv.reader(data_file)
            header = next(data)
            username_index = header.index("username")
            password_index = header.index("password")
            id_index = header.index("id")

            for row in data:
                if (row[username_index] == username and password == row[password_index]):
                    return row[id_index]
            return -1
